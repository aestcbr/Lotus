function showMessage() {
    alert("Bunga teratai melambangkan kedamaian dan keindahan 🌸");
}
