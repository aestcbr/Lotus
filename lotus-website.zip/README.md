# 🌸 Lotus (Teratai) Website Project

Project website sederhana bertema bunga teratai.

## Fitur
- Desain biru tenang (tema air & teratai)
- Galeri gambar
- Tombol interaktif JavaScript

## Cara Menjalankan
1. Download project
2. Buka file index.html di browser

## Cocok Untuk
- Portfolio GitHub
- Belajar HTML, CSS, JavaScript dasar
